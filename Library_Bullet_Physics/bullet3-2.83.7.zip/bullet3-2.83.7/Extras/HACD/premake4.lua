	project "HACD"
		
	kind "StaticLib"
	
	includedirs {"."}
	files {
		"**.cpp",
		"**.h"
	}