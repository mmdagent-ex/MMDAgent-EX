#ifndef PHYSICS_CLIENT_EXAMPLE_H
#define PHYSICS_CLIENT_EXAMPLE_H

class CommonExampleInterface*    PhysicsClientCreateFunc(struct CommonExampleOptions& options);

#endif//PHYSICS_CLIENT_EXAMPLE_H
