ここには Julian 用の文法関連ツールが収められています．

mkdfa (mkdfa.pl) 文法コンパイラ
dfa_minimize	DFA最小化ツール
generate	文ランダム生成ツール
accept_check	単語列の受理/非受理チェックツール
nextword	次単語予測チェックツール（accept_checkの高機能版）
gram2sapixml	Julian 形式の文法を SAPI XML 文法に変換するスクリプト
dfa_determinize	DFA決定化ツール

それぞれのマニュアルは，オンラインマニュアルあるいは
各ディレクトリにある 00readme-ja.txt をご覧ください．
